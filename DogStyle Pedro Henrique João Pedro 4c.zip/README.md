# DogStyle
Primeiro projeto usando NodeJS. 
Site com informações sobre cachorros, com sistema de login, cadastro e perfil.
Admin tem uma página unica aonde pode monitorar a lista de cachorros e suas informações e monitorar cada usuario do site.

## Passo a passo para ver o projeto
1. ### Clone o repositório
2. ### Instale as dependências
            npm install
3. ### Execute o script
            npm run dev
4. ### Entrar no servidor pelo navegador
            http://localhost:3000/