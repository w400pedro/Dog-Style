const users = [
    {id: 'jUK2CmJD', nome: 'Felipe Santos', email: 'papai@riogrande.ifrs.edu.br', senha: '123', data_nascimento: '1980-12-25', racafavorita: '', adm: true, foto: ''},
    {id: 'yGVQC9tF  ', nome: 'Neymar Junior', email: 'neymar@gmail.com', senha: '123', data_nascimento: '2002-02-24', racafavorita: 'Poodle', adm: false , foto: 'https://conteudo.imguol.com.br/c/esporte/f5/2022/03/31/neymar-em-acao-durante-partida-do-psg-no-campeonato-frances-em-marco-de-2022-1648755247588_v2_3x4.jpg'},
    {id: 'C-BpeuaX', nome: 'Pepona', email: 'pepona@gmail.com', senha: 'ugauga', data_nascimento: '2010-10-02', racafavorita: '',  adm: false, foto: ''},
    {id: 'MvJAMVzL', nome: 'Alvares Silva', email: 'alvares@gmail.com', senha: 'uga123', data_nascimento: '2015-08-02', racafavorita: '',  adm: false, foto: 'https://cdn.acritica.net/upload/dn_arquivo/2021/07/douglas-queiroz-2.jpg'}
]
module.exports = users; 